const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true,
  },
  password: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// Middleware to hash the password before saving to the database
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();  // Only hash if password is modified

  // Generate a salt
  const salt = await bcrypt.genSalt(10);  // 10 rounds of salt generation
  this.password = await bcrypt.hash(this.password, salt);  // Hash the password

  next();  // Move to the next step (saving the user)
});

// Method to compare password during login
userSchema.methods.comparePassword = async function(password) {
  return await bcrypt.compare(password, this.password);  // Compare the hashed password
};

// Create the User model
const User = mongoose.model('User', userSchema);

module.exports = User;

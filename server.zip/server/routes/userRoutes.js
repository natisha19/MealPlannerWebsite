const express = require('express');
const User = require('./models/User');
const router = express.Router();

router.post('/register', async (req, res) => {
  const { username, email, password } = req.body;

  try {
    // Check if user already exists
    const existingUser = await User.findOne({ 
      $or: [{ email }, { username }] 
    });

    if (existingUser) {
      return res.status(400).json({ 
        message: 'User with this email or username already exists' 
      });
    }

    // Create new user with plain password
    const newUser = new User({
      username,
      email,
      password
    });

    // Save user to database
    await newUser.save();

    console.log('User registered successfully:', {
      username: newUser.username,
      email: newUser.email,
      password: newUser.password // Note: This logs the plain password
    });

    res.status(201).json({ 
      message: 'User registered successfully',
      userId: newUser._id 
    });

  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ 
      message: 'Error registering user', 
      error: error.message 
    });
  }
});

module.exports = router;
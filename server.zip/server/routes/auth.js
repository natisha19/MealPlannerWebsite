// auth.js
const express = require('express');
const router = express.Router();
const User = require('./models/User'); // Adjust the path as necessary
const jwt = require('jsonwebtoken'); // If you're using JWT for password reset tokens

router.post('/forgot-password', async (req, res) => {
  const { email } = req.body;

  try {
    // Check if the user exists
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: 'User  not found' });
    }

    // Generate a password reset token (if needed)
    const resetToken = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

    // Simulate sending an email (you would use a real email service here)
    console.log(`Password reset link: http://localhost:3000/reset-password?token=${resetToken}`);

    return res.status(200).json({ message: 'Password reset email sent' });
  } catch (error) {
    console.error('Error in password reset:', error);
    return res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
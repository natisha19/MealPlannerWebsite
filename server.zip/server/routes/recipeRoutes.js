// routes/recipeRoutes.js
const express = require('express');
const multer = require('multer');
const path = require('path');
const Recipe = require('../models/Recipe'); // Assuming you have a Recipe model
const router = express.Router();

// Multer setup for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './uploads/'); // directory to save uploaded files
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // unique filename
  },
});

const upload = multer({ storage });

// Get recipes (with optional category filter)
router.get('/recipes', async (req, res) => {
  try {
    const { category } = req.query; // Get category from query parameter
    let recipes;
    if (category) {
      recipes = await Recipe.find({ category }); // Filter recipes by category
    } else {
      recipes = await Recipe.find(); // Fetch all recipes if no category is provided
    }
    res.status(200).json(recipes);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching recipes', error });
  }
});



// Add a new recipe
router.post('/recipes', upload.single('image'), async (req, res) => {
  try {
    console.log('Request Body:', req.body); // Log request data
    console.log('Uploaded File:', req.file); // Log uploaded file

    const { name, ingredients, instructions,description, food_type, category } = req.body;
    const image = req.file ? req.file.path : null;

    // Assuming you save the recipe in the database here
    // Example: Save to the database
    const newRecipe = new Recipe({
      name,
      ingredients,
      instructions,
      category,
      description,
      food_type,
      image,
    });

    await newRecipe.save();

    res.status(200).json({ message: 'Recipe added successfully!' });
  } catch (error) {
    console.error('Error adding recipe:', error);
    res.status(500).json({ message: 'Error adding recipe' });
  }
});

router.delete('/recipes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const recipe = await Recipe.findByIdAndDelete(id);

    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }

    res.status(200).json({ message: 'Recipe deleted successfully' });
  } catch (error) {
    console.error('Error deleting recipe:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

module.exports = router; // Export the router

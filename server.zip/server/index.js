// server/index.js
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser'); // for parsing JSON or URL-encoded data
const recipeRoutes = require('./routes/recipeRoutes');
const contactRoutes = require('./routes/contact');
const app = express();
const User = require('./models/User');
const PORT = process.env.PORT || 5000;

// Middleware
app.use(express.json());
app.use(cors()); // Allow cross-origin requests
app.use('/', recipeRoutes);
app.use('/contact', contactRoutes);

app.use('/uploads', express.static('uploads'));

// Base route
app.get('/', (req, res) => {
  res.send('Meal Planner API');
});

// MongoDB connection
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch((error) => console.error('MongoDB connection error:', error));

// User Schema
/*const userSchema = new mongoose.Schema({
  username: String,
  email: { type: String, unique: true },
  password: String,
});

const User = mongoose.model('User', userSchema);*/

// Registration Route
app.post('/register', async (req, res) => {
  const { username, email, password } = req.body;
  // Check if the user already exists (by username or email)
  const existingUser = await User.findOne({ username });
  if (existingUser) {
      return res.status(400).json({ error: 'Username already exists' });
  }

  const existingEmail = await User.findOne({ email });
  if (existingEmail) {
      return res.status(400).json({ error: 'Email already registered' });
  }

  // Create a new user instance with the provided username, password, and email
  const newUser = new User({
      username,
      password,  // Password will be hashed automatically by Mongoose pre-save hook
      email,
  });

  try {
  
    await newUser.save();
    res.status(201).send('User registered successfully');
    console.log(`New user registered:
      Username: ${username}
      Email: ${email}
      Password (plaintext): ${password}
    `);
  } catch (error) {
    console.error(error);
    res.status(500).send('Error registering user');
  }
});

// Login Route
app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log('Request Body:', req.body);
    if (!email || !password) {
      console.log('Missing email or password:', req.body);
      return res.status(400).json({ message: 'Email and password are required' });
    }

    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      console.log(`Login attempt failed: Email not found - ${email}`);
      return res.status(404).json({ message: 'User not found' });
    }

    console.log('Password entered:', password);
    console.log('Stored hashed password:', user.password);

    // Check if the password matches
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      console.log(`Login attempt failed: Invalid password for email - ${email}`);
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Generate JWT token
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

    // Send only one response with the token and user info
    console.log(`User logged in: ${email}`);
    return res.status(200).json({
      message: 'Login successful',
      token,
      user: { id: user._id, username: user.username, email: user.email },
    });
  } catch (error) {
    console.error(`Error during login: ${error.message}`);
    if (!res.headersSent) {
      return res.status(500).json({ message: 'Server error during login' });
    }
  }
});

// Middlewares
app.use(bodyParser.json()); // Allows handling JSON in the request body
app.use(bodyParser.urlencoded({ extended: true })); // Allows handling form data

// Use the recipe routes with the /api prefix
app.use('/api', recipeRoutes);
// Start Server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
